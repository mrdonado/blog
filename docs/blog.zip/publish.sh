./build.sh
git add --all
git commit -m "Blog update."
git push
